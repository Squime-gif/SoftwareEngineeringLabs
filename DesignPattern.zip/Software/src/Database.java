public class Database {
    private String name;
    private static Database instance;

    private Database(String name){
        this.name=name;
    }

    public void getConnection(){
        System.out.printf("You are connected to the database %s\n",name);
    }

    public static Database createInstance(String name){
        if(instance==null){
            instance=new Database(name);
        }
        return instance;


    }


}
