public class Client {
    public static void main1()
    {
        Program1 p = new Program1();
        System.out.println("I am main1");
        p.go();
    }
    public static void main2()
    {
        Program2 p = new Program2();
        System.out.println("I am main2");
        p.go();
    }
    public static void main3()
    {
        Program3 p = new Program3();
        System.out.println("I am main3");
        p.go();
    }
    void main(){
        Client.main1();
        Client.main2();
        Client.main3();

    }

 }

