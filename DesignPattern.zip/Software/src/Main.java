void main() {
    Database d=Database.createInstance("School");
    Database d2=Database.createInstance("Factory");

    d2.getConnection();
    d.getConnection();

}